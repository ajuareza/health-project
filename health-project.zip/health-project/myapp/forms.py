from django import forms
from .models import Input, DISEASES

class InputForm(forms.ModelForm):
    attrs = {'class ' : 'form-nav-control', 'onchange ' : 'this.form.submit()'}
    disease = forms.ChoiceField(choices=DISEASES, required=True, widget=forms.Select())

    class Meta:
        model = Input
        fields = ['disease']
