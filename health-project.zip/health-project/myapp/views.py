from django.shortcuts import render
import matplotlib.pyplot as plt
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.core.urlresolvers import reverse_lazy
import matplotlib.pyplot as plt, numpy as np
from django.views.generic import FormView
from .forms import InputForm
#from .forms import DiseasesForm
from .models import DISEASES_DICT
from os.path import join
from django.conf import settings
from io import BytesIO
import pandas as pd

def index(request):
    return HttpResponse("Que pasó, parcerooooos")

def webhealth(request):
    return render(request, 'webhealth.html')

def csv(request, year = None):
   filename = join(settings.STATIC_ROOT, 'myapp/data.csv')
   df = pd.read_csv(filename)
   table = df.to_html(float_format = "%.3f", classes = "table table-striped", index_names = False)
   table = table.replace('border="1"','border="0"')
   table = table.replace('style="text-align: right;"', "") # control this in css, not pandas.
   return HttpResponse(table)

def display_table(request, c=""):
    disease = request.GET.get('disease', 'Tuberculosis')
    filename = join(settings.STATIC_ROOT , 'myapp/data.csv' )
    df = pd.read_csv(filename)
    df = df[df["Cause"] == disease]
    if not df.size: return HttpResponse("Choose another disease")
    table = df.to_html(float_format = "%.3f", classes = "table table-striped", index = False)
    table = table.replace('border="1"','border="0"')
    table = table.replace('style="text-align: right;"', "") # control this in css, not pandas.
    params = {'title' : "disease",
           'form_action' : reverse_lazy('myapp:display_table'),
           'form_method' : 'get',
           'form' : InputForm({'disease' : disease}),
           'disease' : DISEASES_DICT[disease],
           'html_table' : table }
    return render(request, 'view_table.html', params)

def display_plot(request, c = ""):
   filename = join(settings.STATIC_ROOT, 'myapp/data.csv')
   df = pd.read_csv(filename, index_col = "id", parse_dates = ["id"])
   df = df[df["Cause"] == c]
   if not df.size: return HttpResponse("No such disease!")
   ax =  ax = df.plot(kind='scatter', x='Value', y='Lower bound')
   ax.set_ylabel("Infant mortality")
   figfile = BytesIO()
   plt.subplots_adjust(bottom = 0.16)
   try: ax.figure.savefig(figfile, format = 'png')
   except ValueError: raise Http404("No such color")
   figfile.seek(0) # rewind to beginning of file
   #return HttpResponse(figfile.read(), content_type="image/png")

def get_reader(request):
    d = dict(request.GET._iterlists())
    return HttpResponse(str(d))

def static_site(request):
    return render(request, "static_site.html")

class FormClass(FormView):
    template_name = 'forms.html'
    form_class = InputForm

def get(self, request):
  disease = request.GET.get('disease', '')
  return render(request, self.form.html, {'form_action' : reverse_lazy('myapp:formclass'),
                                                  'form_method' : 'get',
                                                  'form' : InputForm({'disease' : disease}),
                                                  'disease' : DISEASES_DICT[disease]})
def post(self, request):
  disease = request.POST.get('disease', '')
  return render(request, self.form.html, {'form_action' : reverse_lazy('myapp:formclass'),
                                                  'form_method' : 'get',
                                                  'form' : InputForm({'disease' : disease}),
                                                  'disease' : DISEASES_DICT[disease]})
def form(request):
    disease = request.GET.get('disease', 'Tuberculosis')
    params = {'form_action' : reverse_lazy('myapp:form'),
              'form_method' : 'get',
              'form' : InputForm({'disease' : disease}),
              'disease' : DISEASES_DICT[disease]}
    return render(request, 'form.html', params)

def other(request):
    disease = request.GET.get('disease', '')
    if not disease: disease = request.POST.get('disease', '')

    params = {'form_action' : reverse_lazy('myapp:form'),
              'form_method' : 'get',
              'form' : InputForm({'disease' : disease}),
              'disease' : disease}
    return render(request, 'other.html', params)

def measurements(request):
    disease = request.GET.get('disease', '')
    if not disease: disease = request.POST.get('disease', '')

    params = {'form_action' : reverse_lazy('myapp:form'),
              'form_method' : 'get',
              'form' : InputForm({'disease' : disease}),
              'disease' : disease}
    return render(request, 'measurements.html', params)

def table(request):
    df = pd.DataFrame(np.random.randn(10, 5), columns=['a', 'b', 'c', 'd', 'e'])
    table = df.to_html(float_format = "%.3f", classes = "table table-striped", index_names = False)
    table = table.replace('border="1"','border="0"')
    table = table.replace('style="text-align: right;"', "")
    return HttpResponse(table)

def plot(request):
    df = pd.read_csv(filename, index_col = "id", parse_dates = ["id"])
    df = df[df["Cause"] == c]
    ax =  ax = df.plot(kind='scatter', x='Value', y='Lower bound')
    ax.set_ylabel("Infant mortality")
    figfile = BytesIO()
    plt.subplots_adjust(bottom = 0.16)
    return HttpResponse(plot)

def display_pic(request, c = 'r'):
    disease = request.GET.get('disease', '')
    params = {'title' : disease,
              'form_action' : reverse_lazy('myapp:display_pic'),
              'form_method' : 'get',
              'form' : InputForm({'disease' : disease}),
              'pic_source' : reverse_lazy("myapp:plot", kwargs = {'c' : disease})}
    return render(request, 'view_pic.html', params)

def pic(request, c = None):
    t = np.linspace(0, 2 * np.pi, 30)
    u = np.sin(t)
    plt.figure() # needed, to avoid adding curves in plot
    plt.plot(t, u, color = c)
    figfile = BytesIO()
    try: plt.savefig(figfile, format = 'png')
    except ValueError: raise Http404("No such color")
    figfile.seek(0) # rewind to beginning of file
    return HttpResponse(figfile.read(), content_type="image/png")
